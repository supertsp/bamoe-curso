package ${package};

public class ${sampleClassName} {

    public ${sampleClassName}() {
    }
}
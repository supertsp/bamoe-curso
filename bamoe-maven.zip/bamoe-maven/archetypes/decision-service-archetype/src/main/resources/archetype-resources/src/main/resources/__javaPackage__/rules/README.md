# Rule Resource Files
Add any business automation asset file, such as:

- .DRL     - Drools Rule Language Files
- .DSL     - Drools Domain Specific Language Model Files
- .DRL.XLS - Drools Decision Tables (Excel)
- .DMN     - Decision Modeling & Notation Files (DMN)
- .BPMN    - Stateless Process Files (BPMN)
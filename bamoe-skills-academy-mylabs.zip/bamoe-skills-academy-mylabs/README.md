# IBM Business Automation Manager Open Editions (BAMOE) Skills Academy - My Labs

# Overview
This repository includes all labs created by the student during the `BAMOE Skills Academy`.

# Guidelines
Use the supplied [Maven Archetypes](../bamoe-maven/README.md) in order to generate the lab project of your choice.  You can emplly a `multi-module` approach to your labs, creating a project for each appliation and then creating a master `pom.xml` that builds all of them in one step.


# IBM Business Automation Manager Open Editions (BAMOE) Skills Academy Examination

## Overview
![Under Construction](/doc/images/under-construction.png)



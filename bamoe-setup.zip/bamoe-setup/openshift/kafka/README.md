# IBM Business Automation Manager Open Editions - Setup Instructions for Red Hat OpenShift - Apache Kafka

1.  Login to OpenShift cluster...
2.  Select target project: ex: _(oc project bamoe)_
3.  Install operator: strimzi-cluster-operator.v0.44.0 provided by Strimzi, use 0.44.0 (Kafka 3.8.0)
4.  Configure via operator

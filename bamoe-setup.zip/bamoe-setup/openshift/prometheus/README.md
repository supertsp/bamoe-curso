# IBM Business Automation Manager Open Editions - Setup Instructions for Red Hat OpenShift - Prometheus Monitoring

1.  Login to OpenShift cluster...
2.  Select target project: ex: _(oc project bamoe)_
3.  Install operator: prometheusoperator.0.56.3 provided by Craig Trought
4.  Configure via operator
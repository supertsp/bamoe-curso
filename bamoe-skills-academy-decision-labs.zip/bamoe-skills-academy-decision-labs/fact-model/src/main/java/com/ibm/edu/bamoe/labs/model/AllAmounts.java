package com.ibm.edu.bamoe.labs.model;

public class AllAmounts {

    private int amounts;

    public AllAmounts(int amounts) {
        this.amounts = amounts;
    }

    public int getAmounts() {
        return amounts;
    }

    public void setAmounts(int amounts) {
        this.amounts = amounts;
    }
}
